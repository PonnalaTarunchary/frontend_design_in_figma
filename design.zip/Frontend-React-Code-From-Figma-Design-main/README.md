# Created Front-End React Code from the provided Figma Design from scratch

This is from a work I did voluntarily for an educational website named 'Medhavhi'. I was provided a Figma Design by the company and I wrote all the Front-End Code using Tailwind CSS & ReactJS fro them.

## Figma Design:
![medhavhi figma design](https://github.com/deadclown09/Frontend-React-Code-From-Figma-Design/blob/main/FigmaDesign.png?raw=true)

## Website link:
https://medhavhifigma-sandesh.netlify.app/
